package com.example.settings;

public class Settings extends Prefe {
}
